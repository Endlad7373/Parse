from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter
import time

# Настройки
WAIT_TIME = 10  # время ожидания в секундах
EXCEL_FILE = "Vitamins.xlsx"

# Категории и их URL
CATEGORIES = {
    "Минералы": "https://ru.siberianhealth.com/ru/shop/catalog/vse-mineraly-12/",
    "Мультивитамины": "https://ru.siberianhealth.com/ru/shop/catalog/vse-multivitaminy-11/",
    "Омега 3,6,9": "https://ru.siberianhealth.com/ru/shop/catalog/omega-3-6-9-13/",
    "Витамин D": "https://ru.siberianhealth.com/ru/shop/catalog/vitamin-d-241/",
    "Пробиотики и сорбенты": "https://ru.siberianhealth.com/ru/shop/catalog/probiotiki-i-sorbenty-125/",
    "Готовые программы": "https://ru.siberianhealth.com/ru/shop/catalog/gotovye-programmy-243/"
}

# Настройка Chrome в headless-режиме
chrome_options = Options()
chrome_options.add_argument("--headless")  # Включение headless-режима
chrome_options.add_argument("--window-size=1920,1080")  # Установка размера окна
chrome_options.add_argument("--disable-gpu")  # Отключение GPU для стабильности
chrome_options.add_argument("--no-sandbox")  # Отключение sandbox
chrome_options.add_argument("--disable-dev-shm-usage")  # Решение проблем с памятью
chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36")  # Установка User-Agent

driver = webdriver.Chrome(options=chrome_options)

# Создаем новую книгу Excel
wb = Workbook()
ws = wb.active
ws.title = "Товары"

# Заголовки столбцов
headers = ["Категория", "Цена", "Наименование", "Доступность", "Объем"]
ws.append(headers)

# Форматируем заголовки
bold_font = Font(bold=True)
for col in range(1, len(headers) + 1):
    ws[f"{get_column_letter(col)}1"].font = bold_font

try:
    for category_name, url in CATEGORIES.items():
        print(f"Обрабатываю категорию: {category_name}")
        
        # Открываем страницу
        driver.get(url)
        time.sleep(WAIT_TIME)
        
        # Находим все элементы товаров
        product_cards = driver.find_elements(By.CSS_SELECTOR, 'a.im21--product-card')
        
        for card in product_cards:
            try:
                # Наименование товара
                name = card.find_element(By.CSS_SELECTOR, '.im21--product-card__name').text.strip()
                
                # Цена
                price = "Нет в наличии"
                try:
                    price_element = card.find_element(By.CSS_SELECTOR, '.im21--product-card-price__price')
                    price = price_element.text.strip()
                except:
                    pass
                
                # Доступность
                availability = "В наличии"
                if "im21--product-card_not-available" in card.get_attribute("class"):
                    availability = "Нет в наличии"
                
                # Объем (если есть)
                volume = ""
                try:
                    volume_element = card.find_element(By.CSS_SELECTOR, '.im21--product-card__info')
                    volume = volume_element.text.strip()
                except:
                    pass
                
                # Записываем данные в Excel
                ws.append([category_name, price, name, availability, volume])
                
            except Exception as e:
                print(f"Ошибка при обработке товара: {e}")
                continue
        
        print(f"Обработано товаров: {len(product_cards)}")

    # Настраиваем ширину столбцов
    column_widths = {
        'A': 25,  # Категория
        'B': 15,  # Цена
        'C': 40,  # Наименование
        'D': 15,  # Доступность
        'E': 20   # Объем
    }
    
    for col, width in column_widths.items():
        ws.column_dimensions[col].width = width
    
    # Сохраняем файл Excel
    wb.save(EXCEL_FILE)
    print(f"\nВсе данные успешно сохранены в файл {EXCEL_FILE}")

finally:
    # Закрываем браузер
    driver.quit()