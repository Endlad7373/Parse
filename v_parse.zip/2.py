
import os
import random
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import openpyxl

# Конфигурация
SPREADSHEET_ID = '1MOoC3c0xLQdk_bDPnPVSi7cG3IjmoErayKjZgaSox8Q'
SHEET_NAME = 'vr'  # Имя листа в Google таблице
EXCEL_FILE = 'Vitamins.xlsx'
SERVICE_ACCOUNT_FILES = [
    '1.json',
    '2.json'
]

def read_excel_data(file_path):
    """Чтение данных из Excel файла"""
    try:
        wb = openpyxl.load_workbook(file_path)
        sheet = wb.active
        data = []
        
        for row in sheet.iter_rows(values_only=True):
            data.append(list(row))
            
        return data
    except Exception as e:
        print(f"Ошибка при чтении Excel файла: {e}")
        return None

def initialize_services():
    services = []
    for sa_file in SERVICE_ACCOUNT_FILES:
        creds = Credentials.from_service_account_file(
            sa_file,
            scopes=['https://www.googleapis.com/auth/spreadsheets']
        )
        service = build('sheets', 'v4', credentials=creds)
        services.append(service)
    return services

def clear_sheet(service):
    try:
        service.spreadsheets().values().clear(
            spreadsheetId=SPREADSHEET_ID,
            range=f'{SHEET_NAME}!A:Z',
            body={}
        ).execute()
        print("Лист успешно очищен")
        return True
    except HttpError as e:
        print(f"Ошибка при очистке листа: {e}")
        return False

def update_sheet(service, data):
    try:
        body = {
            'valueInputOption': 'USER_ENTERED',
            'data': [{
                'range': f'{SHEET_NAME}!A1',
                'majorDimension': 'ROWS',
                'values': data
            }]
        }
        service.spreadsheets().values().batchUpdate(
            spreadsheetId=SPREADSHEET_ID,
            body=body
        ).execute()
        print("Данные успешно загружены")
        return True
    except HttpError as e:
        print(f"Ошибка при загрузке данных: {e}")
        if 'quota' in str(e).lower():
            print("Превышена квота, пробуем другой аккаунт")
        return False

def main():
    # Получаем абсолютный путь к Excel файлу
    excel_path = os.path.join(os.path.dirname(__file__), EXCEL_FILE)
    
    # Читаем данные из Excel
    data = read_excel_data(excel_path)
    if not data:
        print("Не удалось прочитать данные из Excel файла")
        return
    
    services = initialize_services()
    current_service = random.choice(services)
    print(f"Используется сервисный аккаунт: {SERVICE_ACCOUNT_FILES[services.index(current_service)]}")
    
    if not clear_sheet(current_service):
        current_service = next(s for s in services if s != current_service)
        print(f"Переключение на сервисный аккаунт: {SERVICE_ACCOUNT_FILES[services.index(current_service)]}")
        if not clear_sheet(current_service):
            print("Не удалось очистить лист ни одним из аккаунтов")
            return
    
    if not update_sheet(current_service, data):
        current_service = next(s for s in services if s != current_service)
        print(f"Переключение на сервисный аккаунт: {SERVICE_ACCOUNT_FILES[services.index(current_service)]}")
        if not update_sheet(current_service, data):
            print("Не удалось загрузить данные ни одним из аккаунтов")
            return
    
    print("Операция успешно завершена")

if __name__ == '__main__':
    main()